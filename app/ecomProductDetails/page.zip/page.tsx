"use client"
import React from "react";
import Link from "next/link";
import { useSearchParams } from "next/navigation";

const EcomProductDetails = () => {
    const searchParams = useSearchParams();
    const id = parseInt(searchParams.get("id")); // Convert ID to integer
    const category = parseInt(searchParams.get("category"));

    // Retrieve the array of products from local storage
    const storedProducts = localStorage.getItem("listedProducts");



    const parsedProducts = JSON.parse(storedProducts);

    const selectedProduct = parsedProducts.find((product: any) => product.ID === id && product.category === category);
    console.log(selectedProduct);


    return (
        <>
            <h1>Listed Product Details</h1>
            <p>ID: {id}</p>
            <p>Category: {category}</p>

            <div>
                <img src={selectedProduct.image_url} alt={selectedProduct.name} />
                <h2>{selectedProduct.name}</h2>
                <p>{selectedProduct.description}</p>
                <p>{selectedProduct.price}</p>
                <p>{selectedProduct.brand}</p>
                <p>{selectedProduct.material}</p>
                <p>{selectedProduct.capacity}</p>
                <p>{selectedProduct.color}</p>
                <p>{selectedProduct.dishwasher_safe ? 'Dishwasher Safe' : 'Not Dishwasher Safe'}</p>
                <p>{selectedProduct.package_includes.join(', ')}</p>
                <p>{selectedProduct.in_stock ? 'In Stock' : 'Out of Stock'}</p>
            </div>

            <div>
                <Link href="/products"> </Link>
            </div>
        </>
    );
};

export default EcomProductDetails;
